// phaseC/reactions.js
// -------------------------------------------------------------
// Handler untuk event messages.reaction dari Baileys.
//
// Alur:
// 1. Ambil reaction.key (pesan yang direact) → messageId
// 2. Cek messageIndex → occurrenceKey → occurrence + task
// 3. Cek user canonical (from reaction key/participant)
// 4. Kalau belum tercatat di occurrence.completedBy → +poin & catat
// 5. Kirim konfirmasi HANYA di grup tugas
// 6. Kalau sudah pernah dapat poin untuk occurrence ini → info sudah selesai
//
// Anti-duplikasi key: taskId + date + canonicalUserId (via completedBy map)
// -------------------------------------------------------------

import {
    loadMessageIndex,
    loadOccurrences,
    saveOccurrences,
    loadTasks
} from './tasks.js';
import { addPoints, getPointsSnapshot } from './points.js';
import {
    canonicalFromMessageKey,
    allCandidatesFromMessageKey,
    resolveCanonicalPhone,
    displayNameFromUsers
} from './identity.js';
import { appendLog } from './store.js';

// Baileys mengirim reaction sebagai messages.upsert dengan
// message.reactionMessage ATAU sebagai event 'messages.reaction'.
// Kita handle keduanya lewat ekstraktor tunggal.
function extractReactionInfo(evtItem) {
    // Bentuk 1: dari 'messages.reaction' event
    //   { key, reaction: { key, text, senderTimestampMs } }
    if (evtItem && evtItem.reaction && evtItem.reaction.key) {
        return {
            targetKey: evtItem.reaction.key,
            emoji: evtItem.reaction.text || '',
            reactorKey: evtItem.key || evtItem.reaction.key
        };
    }
    // Bentuk 2: dari 'messages.upsert' dengan reactionMessage embed
    if (evtItem && evtItem.message && evtItem.message.reactionMessage) {
        const rm = evtItem.message.reactionMessage;
        return {
            targetKey: rm.key,
            emoji: rm.text || '',
            reactorKey: evtItem.key
        };
    }
    return null;
}

export async function handleReactionEvent(ctx, evtItem) {
    const info = extractReactionInfo(evtItem);
    if (!info || !info.targetKey || !info.targetKey.id) return;

    // Emoji kosong = un-react → abaikan.
    if (!info.emoji) {
        appendLog('REACT', 'Un-react diabaikan', `msg=${info.targetKey.id}`);
        return;
    }

    const messageId = info.targetKey.id;
    const idx = loadMessageIndex();
    const occurrenceKey = idx[messageId];
    if (!occurrenceKey) return; // bukan pesan tugas

    const occurrences = loadOccurrences();
    const occurrence = occurrences[occurrenceKey];
    if (!occurrence) return;

    const tasks = loadTasks();
    const task = tasks[occurrence.taskId];
    if (!task) return;

    // Resolusi identitas: prefer canonical PHONE dari users.json (via alias),
    // fallback ke normalizeUserId first-candidate.
    const rawCandidates = allCandidatesFromMessageKey(info.reactorKey);
    const users = ctx.loadUsers ? ctx.loadUsers() : null;
    let canonicalId = resolveCanonicalPhone(rawCandidates, users, ctx.normalizeUserId);
    if (!canonicalId) {
        // fallback lama
        canonicalId = canonicalFromMessageKey(info.reactorKey, ctx.normalizeUserId);
    }
    if (!canonicalId) {
        appendLog('REACT', 'Canonical id kosong, reaction diabaikan',
            `msg=${messageId} raw=${JSON.stringify(info.reactorKey)}`);
        return;
    }

    // Reactor adalah bot sendiri? skip.
    const botCanonical = ctx.normalizeUserId(
        (ctx.sock?.user?.id || '').split(':')[0].split('@')[0]
    );
    if (botCanonical && canonicalId === botCanonical) return;

    const groupChatId = task.chatId;

    // Nama tampilan: (1) users.json → (2) participant grup → (3) canonicalId
    let displayName = displayNameFromUsers(canonicalId, users, ctx.normalizeUserId);
    if (!displayName) {
        displayName = await ctx.getDisplayName(canonicalId, groupChatId, rawCandidates).catch(() => '');
    }
    if (!displayName) displayName = canonicalId;

    // Anti-duplikasi: sudah pernah selesai untuk occurrence ini?
    if (occurrence.completedBy && occurrence.completedBy[canonicalId]) {
        try {
            await ctx.sock.sendMessage(groupChatId, {
                text: `ℹ️ ${occurrence.completedBy[canonicalId] || displayName}, tugas ini sudah kamu selesaikan hari ini.`
            });
        } catch (error) {
            appendLog('WARN', 'Gagal kirim info duplikasi', error?.message || error);
        }
        return;
    }

    // Beri poin.
    if (!occurrence.completedBy) occurrence.completedBy = {};
    occurrence.completedBy[canonicalId] = displayName;
    saveOccurrences(occurrences);

    addPoints(canonicalId, displayName, task.points);

    appendLog('REACT',
        `Tugas diselesaikan +${task.points}`,
        `occ=${occurrenceKey} user=${canonicalId} name="${displayName}"`);

    try {
        await ctx.sock.sendMessage(groupChatId, {
            text: `✅ Tugas telah diselesaikan oleh *${displayName}*.\n🏅 +${task.points} poin`
        });
    } catch (error) {
        appendLog('WARN', 'Gagal kirim konfirmasi tugas', error?.message || error);
    }

    // Sentuh snapshot poin biar auto-reset bulan tetap konsisten
    getPointsSnapshot();
}
