// phaseC/roasting.js
// -------------------------------------------------------------
// Roasting + motivasi ringan untuk peringkat bawah leaderboard.
// - Playful, tidak menyerang tubuh/keluarga/agama/etnis/karakter.
// - Pesan bervariasi (rotasi random) agar tidak monoton.
// - Untuk Fase D, AI dapat menghasilkan variasi tambahan; di sini
//   kita pakai template lokal.
// -------------------------------------------------------------

const ROASTING = [
    (name) => `😏 ${name}, podium sudah kelihatan... tinggal panjat.`,
    (name) => `🥲 ${name}, semangat! Grafiknya lagi cari arah naik.`,
    (name) => `☕ ${name}, kopinya udah dingin. Waktunya beraksi.`,
    (name) => `📉 ${name}, peringkatmu perlu upgrade — masih ada waktu.`,
    (name) => `🚶 ${name}, jalan santai boleh, tapi jangan mampir tidur.`,
    (name) => `🧘 ${name}, meditasi udah cukup. Sekarang eksekusi.`,
    (name) => `🐢 ${name}, pelan boleh — asal jangan berhenti.`,
    (name) => `🔋 ${name}, baterai low. Isi ulang dan tancap gas.`
];

const MOTIVASI = [
    () => `💪 Besok waktunya naik peringkat!`,
    () => `🚀 Peluang selalu ada di occurrence berikutnya.`,
    () => `🌱 Konsistensi kecil, hasil besar.`,
    () => `🎯 Fokus lagi besok, satu tugas satu langkah.`,
    () => `🔥 Satu reaction sederhana bisa mengubah peringkat.`
];

function pick(list) {
    return list[Math.floor(Math.random() * list.length)];
}

// entries = leaderboard sudah tersortir dari getLeaderboard()
// Ambil 1-2 peringkat bawah untuk di-roast, sisanya diberi motivasi umum.
export function buildRoasting(entries) {
    if (!Array.isArray(entries) || entries.length === 0) return '';
    const tail = entries.slice(-Math.min(2, entries.length));
    // Kalau leaderboard cuma 1 orang, biarkan motivasi saja
    const lines = [];
    if (entries.length >= 3) {
        for (const e of tail) {
            lines.push(pick(ROASTING)(e.name || e.id));
        }
    }
    lines.push(pick(MOTIVASI)());
    return lines.join('\n');
}
