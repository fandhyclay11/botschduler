// phaseC/points.js
// -------------------------------------------------------------
// Sistem poin GLOBAL bulan berjalan.
// - Semua poin lintas grup masuk ke akun canonical user.
// - Awal bulan baru: akumulasi direset ke 0 otomatis saat write/read.
// - Identity canonical didefinisikan di identity.js (nomor tanpa
//   simbol, prefix 62 untuk Indonesia).
// - Nama disimpan sebagai display; boleh berubah.
// -------------------------------------------------------------

import { FILES, readJson, writeJson, appendLog } from './store.js';

function currentMonthKey(now = new Date()) {
    const y = now.getFullYear();
    const m = String(now.getMonth() + 1).padStart(2, '0');
    return `${y}-${m}`;
}

function loadRaw() {
    return readJson(FILES.points, { month: '', users: {} });
}

// Auto-reset kalau bulan sudah berganti.
function loadPointsForCurrentMonth() {
    const data = loadRaw();
    const month = currentMonthKey();

    if (data.month !== month) {
        appendLog('POINTS', 'Reset akumulasi bulan baru',
            `dari=${data.month || '(kosong)'} ke=${month}`);
        const fresh = { month, users: {} };
        writeJson(FILES.points, fresh);
        return fresh;
    }

    return data;
}

export function getPointsSnapshot() {
    return loadPointsForCurrentMonth();
}

export function addPoints(canonicalId, displayName, amount) {
    if (!canonicalId || !Number.isFinite(amount)) return null;

    const data = loadPointsForCurrentMonth();

    if (!data.users[canonicalId]) {
        data.users[canonicalId] = {
            id: canonicalId,
            name: displayName || '',
            points: 0
        };
    }

    // Update nama kalau ada nama baru (nama adalah display, boleh berubah).
    if (displayName) {
        data.users[canonicalId].name = displayName;
    }

    data.users[canonicalId].points += Number(amount);
    writeJson(FILES.points, data);

    appendLog('POINTS',
        `+${amount} poin`,
        `user=${canonicalId} name="${data.users[canonicalId].name}" total=${data.users[canonicalId].points}`);

    return data.users[canonicalId];
}

// Leaderboard: ranking global, DIFILTER berdasarkan list canonical
// anggota grup laporan. Kalau memberFilter null => semua user.
export function getLeaderboard(memberFilter = null) {
    const data = loadPointsForCurrentMonth();

    let entries = Object.values(data.users);

    if (Array.isArray(memberFilter)) {
        const allowed = new Set(memberFilter.filter(Boolean));
        entries = entries.filter(e => allowed.has(e.id));
    }

    return entries
        .filter(e => e.points > 0)
        .sort((a, b) => b.points - a.points);
}
